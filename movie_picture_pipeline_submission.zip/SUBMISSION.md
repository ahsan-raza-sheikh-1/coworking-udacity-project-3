# Movie Picture Pipeline Submission

## Required Workflows

* `.github/workflows/frontend-ci.yaml` - frontend lint, test, and gated Docker build on pull requests to `main`.
* `.github/workflows/backend-ci.yaml` - backend lint, test, and gated Docker build on pull requests to `main`.
* `.github/workflows/frontend-cd.yaml` - frontend lint, test, ECR image build/push, and EKS deployment on pushes to `main`.
* `.github/workflows/backend-cd.yaml` - backend lint, test, ECR image build/push, and EKS deployment on pushes to `main`.

All four workflows also support `workflow_dispatch`. AWS credentials are referenced only through GitHub Secrets.

## Deployment Evidence

The applications were built in AWS CodeBuild because Docker Desktop was unavailable locally.

* EKS cluster: `cluster` in `us-east-1`
* Backend image: `backend:cloud-backend-20260915023810`
* Frontend image: `frontend:cloud-frontend-20260915024304`
* Backend API: http://a02c2114e2ffb4b0b8976d392607e56c-1166134380.us-east-1.elb.amazonaws.com/movies
* Frontend application: http://a7c024243e31f43b78c74430083db0ae-618431148.us-east-1.elb.amazonaws.com/

Final verification:

* Backend deployment: `1/1` ready.
* Frontend deployment: `1/1` ready.
* Backend endpoint: HTTP 200 and returns 3 movies.
* Frontend endpoint: HTTP 200 and serves the React root.
* Frontend JavaScript contains the backend LoadBalancer URL supplied through `REACT_APP_MOVIE_API_URL`.

## Required GitHub Configuration

Deployment workflows require these repository secrets:

* `AWS_ACCESS_KEY_ID`
* `AWS_SECRET_ACCESS_KEY`
* `AWS_REGION` (optional; defaults to `us-east-1`)

Set `REACT_APP_MOVIE_API_URL` as a repository variable or secret and optionally set `EKS_CLUSTER_NAME` as a repository variable. Do not commit `.env` or any AWS credential values.

## Package Contents

This submission package excludes local `.env` files, Terraform state and backups, `.terraform`, `node_modules`, React build output, test caches, and Python cache files.